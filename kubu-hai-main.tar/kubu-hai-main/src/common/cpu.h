#ifndef CPU_H
#define CPU_H

// Function declarations
int initialize_cpu();
void finalize_cpu();
void print_cpu_info();

#endif // CPU_H
