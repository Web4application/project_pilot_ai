#ifndef PRINTER_H
#define PRINTER_H

// Function declarations
void print_message(const char *message);
void print_cpu_info();

#endif // PRINTER_H
