#!/bin/bash

# Print Hello, World! to the terminal
echo "Hello, World!"
chmod +x hello_world.sh
