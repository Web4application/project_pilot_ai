<html kubu-hai_mod_h2 test site
    <body>
        <h1>mod_h2 test site</h1>
        <p></p>
        <h2>served directly</h2>
        <ul>
            <li><a href="001.html">01: html</a></li>
            <li><a href="002.jpg">02: image</a></li>
            <li><a href="003.html">03: html+image</a></li>
            <li><a href="004.html">04: tiled image</a></li>
            <li><a href="005.txt">05: large text</a></li>
            <li><a href="006.html">06: html/js/css</a></li>
            <li><a href="007.html">07: form submit</a></li>
            <li><a href="upload.py">08: upload</a></li>
            <li><a href="009.py">09: small chunks</a></li>
        </ul>
        <h2>mod_proxyied</h2>
        <ul>
            <li><a href="proxy/001.html">01: html</a></li>
            <li><a href="proxy/002.jpg">02: image</a></li>
            <li><a href="proxy/003.html">03: html+image</a></li>
            <li><a href="proxy/004.html">04: tiled image</a></li>
            <li><a href="proxy/005.txt">05: large text</a></li>
            <li><a href="proxy/006.html">06: html/js/css</a></li>
            <li><a href="proxy/007.html">07: form submit</a></li>
            <li><a href="proxy/upload.py">08: upload</a></li>
            <li><a href="proxy/009.py">09: small chunks</a></li>
        </ul>
        <h2>mod_rewritten</h2>
        <ul>
            <li><a href="rewrite/001.html">01: html</a></li>
            <li><a href="rewrite/002.jpg">02: image</a></li>
            <li><a href="rewrite/003.html">03: html+image</a></li>
            <li><a href="rewrite/004.html">04: tiled image</a></li>
            <li><a href="rewrite/005.txt">05: large text</a></li>
            <li><a href="rewrite/006.html">06: html/js/css</a></li>
            <li><a href="rewrite/007.html">07: form submit</a></li>
            <li><a href="rewrite/upload.py">08: upload</a></li>
            <li><a href="rewrite/009.py">09: small chunks</a></li>
        </ul>
    </body>
</html>
