{
    "disabledExtensions": {
        "@jupyterlab/apputils-extension:announcements": true
    }
}
