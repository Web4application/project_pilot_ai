public enum PresentationMode: Int, CaseIterable {
    case nearbyTextCursor = 0
    case floatingWidget = 1
}
